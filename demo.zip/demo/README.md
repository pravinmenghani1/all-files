# 🌍 Travel Planning with CrewAI

A production-ready demo of **multi-agent AI** for travel planning, featuring 5 specialized agents, a REST API with streaming, and a full observability stack.

---

## Architecture

```
User Request
     │
     ▼
┌─────────────────────────────────────────────────────┐
│                    Travel Crew                      │
│                                                     │
│  1. Destination Researcher  ──► research report     │
│  2. Flight Scout            ──► flight options      │
│  3. Hotel Curator           ──► hotel picks         │
│  4. Itinerary Planner       ──► day-by-day plan     │
│  5. Budget Analyst          ──► cost breakdown      │
└─────────────────────────────────────────────────────┘
     │
     ▼
FastAPI (REST + SSE)  ──►  OTel Collector  ──►  Jaeger
                      ──►  Prometheus      ──►  Grafana
```

## Project Structure

```
demo/
├── src/
│   ├── tools.py        # 6 custom tools (search, flights, hotels, etc.)
│   ├── agents.py       # 5 specialized agents
│   ├── tasks.py        # Task definitions with context dependencies
│   └── crew.py         # Crew assembly + plan_trip()
├── observability/
│   ├── otel_config.py  # OTel tracing + Prometheus metrics
│   ├── otel-collector.yaml
│   ├── prometheus.yml
│   └── grafana/provisioning/datasources/
├── notebooks/
│   └── travel_demo.ipynb   # Interactive step-by-step walkthrough
├── app.py              # FastAPI server
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

---

## Quick Start

### Option A — Notebook (Recommended for learning)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env
# Edit .env and set: OPENAI_API_KEY=sk-...

# 3. Open the notebook
jupyter notebook notebooks/travel_demo.ipynb
```

Follow the 10 steps in the notebook — each cell builds on the previous one.

### Option B — Run the crew directly

```bash
cp .env.example .env   # set OPENAI_API_KEY
python -m src.crew
```

### Option C — REST API

```bash
# Start the server
uvicorn app:app --reload

# Plan a trip (synchronous)
curl -X POST http://localhost:8000/plan \
  -H "Content-Type: application/json" \
  -d '{
    "origin": "London",
    "interests": "art, food, history",
    "travel_dates": "2025-04-01 to 2025-04-07",
    "budget_level": "mid-range",
    "travelers": 2
  }'

# Stream agent progress (SSE)
curl -N http://localhost:8000/plan/stream \
  -X POST \
  -H "Content-Type: application/json" \
  -d '{"origin":"London","interests":"art","travel_dates":"2025-04-01 to 2025-04-07","budget_level":"mid-range"}'
```

API docs: http://localhost:8000/docs

---

## Docker Deployment (Full Stack)

```bash
# 1. Set your API key
cp .env.example .env
# Edit .env: OPENAI_API_KEY=sk-...

# 2. Start everything
docker compose up --build

# 3. Access services
```

| Service    | URL                          | Credentials  |
|------------|------------------------------|--------------|
| API        | http://localhost:8000/docs   | —            |
| Prometheus | http://localhost:9091        | —            |
| Grafana    | http://localhost:3000        | admin/admin  |
| Jaeger     | http://localhost:16686       | —            |

```bash
# Stop
docker compose down

# Stop and remove volumes
docker compose down -v
```

---

## The 5 Agents

| Agent | Role | Tools |
|-------|------|-------|
| Destination Researcher | Finds destinations matching preferences | web_search, destination_info, weather_forecast |
| Flight Scout | Finds best flight options | flight_search, currency_converter |
| Hotel Curator | Recommends accommodations | hotel_search, currency_converter |
| Itinerary Planner | Builds day-by-day plan | web_search, destination_info |
| Budget Analyst | Estimates costs, suggests savings | currency_converter |

---

## Observability

All observability services start automatically with `docker compose up --build`.

### Services at a Glance

| Service    | URL                    | Purpose                       | Credentials |
|------------|------------------------|-------------------------------|-------------|
| Web UI     | http://localhost:8000  | Travel planner app            | —           |
| Jaeger     | http://localhost:16686 | Distributed traces            | —           |
| Prometheus | http://localhost:9091  | Metrics storage & querying    | —           |
| Grafana    | http://localhost:3000  | Dashboards (metrics + traces) | admin/admin |

---

### Jaeger — Distributed Traces

**http://localhost:16686**

Every `/plan` request is traced end-to-end via OpenTelemetry.

1. Open Jaeger UI
2. Select service: `travel-planning-crew`
3. Click **Find Traces**
4. Click any trace to see the full span breakdown per agent

Each trace includes attributes: `origin`, `budget_level`.

Data flow: `App → OTel Collector → Jaeger`

---

### Prometheus — Metrics

**http://localhost:9091**

Go to the **Graph** tab and run these queries:

| Query | What it shows |
|-------|---------------|
| `trip_requests_total` | Total requests by status (success/error) |
| `rate(trip_requests_total[5m])` | Request throughput over 5 minutes |
| `trip_duration_seconds` | End-to-end planning time histogram |
| `histogram_quantile(0.95, rate(trip_duration_seconds_bucket[5m]))` | p95 latency |
| `agent_task_duration_seconds` | Per-agent task duration |

Prometheus scrapes the app at `http://app:9090/metrics` every 15 seconds.

---

### Grafana — Dashboards

**http://localhost:3000** — login: `admin` / `admin`

Prometheus and Jaeger datasources are **auto-provisioned** on startup — no manual setup needed.

#### Suggested dashboard panels

| Panel title | Query | Visualization |
|-------------|-------|---------------|
| Request Rate | `rate(trip_requests_total[5m])` | Time series |
| p95 Latency | `histogram_quantile(0.95, rate(trip_duration_seconds_bucket[5m]))` | Time series |
| Total Requests | `trip_requests_total` | Stat |
| Error Rate | `trip_requests_total{status="error"}` | Stat |
| Per-agent Duration | `agent_task_duration_seconds` | Bar chart |

#### To create a dashboard
1. Click **+** → **New Dashboard** → **Add visualization**
2. Select datasource: **Prometheus**
3. Paste a query from the table above
4. Save the dashboard

To explore traces inside Grafana: **Explore** → select datasource **Jaeger** → search by service or trace ID.

---

### Health Check

```bash
curl http://localhost:8000/health
# {"status": "ok"}
```

---

## Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | required | OpenAI API key |
| `MODEL` | `gpt-4o-mini` | LLM model |
| `SERPER_API_KEY` | optional | Real web search (falls back to mock) |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | optional | OTel collector endpoint |
| `PORT` | `8000` | API server port |

---

## Step-by-Step Learning Path

1. **Read `src/tools.py`** — understand the 6 tools available to agents
2. **Read `src/agents.py`** — see how each agent is configured with role + backstory + tools
3. **Read `src/tasks.py`** — understand task descriptions and context dependencies
4. **Read `src/crew.py`** — see how the crew is assembled and run
5. **Run the notebook** — execute each step interactively
6. **Start the API** — test REST endpoints with curl or the Swagger UI
7. **Deploy with Docker** — bring up the full observability stack
8. **Explore Grafana** — build dashboards from the Prometheus metrics
9. **Explore Jaeger** — inspect distributed traces for each request
10. **Customize** — add your own agents, tools, or tasks
