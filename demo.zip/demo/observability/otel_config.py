"""
OpenTelemetry + Prometheus setup.
Call setup_telemetry() once at app startup.
"""
import os
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from prometheus_client import Counter, Histogram, start_http_server

# ── Prometheus metrics ────────────────────────────────────────────────────────
trip_requests_total = Counter(
    "trip_requests_total", "Total trip planning requests", ["status"]
)
trip_duration_seconds = Histogram(
    "trip_duration_seconds", "Time to complete a trip plan",
    buckets=[5, 10, 30, 60, 120, 300, 600],
)
agent_task_duration_seconds = Histogram(
    "agent_task_duration_seconds", "Time per agent task",
    labelnames=["agent"],
    buckets=[1, 5, 10, 30, 60, 120],
)

# ── OpenTelemetry tracer ──────────────────────────────────────────────────────
_tracer: trace.Tracer | None = None


def setup_telemetry(prometheus_port: int = 9090) -> trace.Tracer:
    """Initialize OTel tracing and start Prometheus metrics server."""
    global _tracer

    resource = Resource.create({
        "service.name": os.getenv("OTEL_SERVICE_NAME", "travel-crew"),
        "service.version": "1.0.0",
    })

    provider = TracerProvider(resource=resource)

    otlp_endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
    if otlp_endpoint:
        exporter = OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))

    trace.set_tracer_provider(provider)
    _tracer = trace.get_tracer(__name__)

    # Start Prometheus metrics endpoint on a separate port
    try:
        start_http_server(prometheus_port)
        print(f"📊 Prometheus metrics: http://localhost:{prometheus_port}")
    except OSError:
        pass  # Already started (e.g., during hot reload)

    return _tracer


def get_tracer() -> trace.Tracer:
    return _tracer or trace.get_tracer(__name__)
