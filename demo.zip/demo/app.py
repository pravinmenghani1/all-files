"""
FastAPI server for the Travel Planning Crew.
Endpoints:
  POST /plan          — run full crew, return JSON result
  POST /plan/stream   — stream agent progress via SSE
  GET  /health        — health check
  GET  /metrics       — Prometheus metrics (redirects to :9090)
"""
import time
import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse
from dotenv import load_dotenv

from observability.otel_config import (
    setup_telemetry, get_tracer,
    trip_requests_total, trip_duration_seconds,
)
from src.crew import build_crew, plan_trip

load_dotenv()


# ── Startup / shutdown ────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_telemetry(prometheus_port=9090)
    yield


app = FastAPI(
    title="Travel Planning Crew API",
    description="Multi-agent travel planning powered by CrewAI",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def root():
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/static/index.html")


# ── Request / Response models ─────────────────────────────────────────────────
class TripRequest(BaseModel):
    origin: str = Field(..., example="New York")
    interests: str = Field(..., example="culture, food, history")
    travel_dates: str = Field(..., example="2025-03-10 to 2025-03-17")
    budget_level: str = Field("mid-range", example="mid-range")
    travelers: int = Field(2, ge=1, le=20)


# ── Endpoints ─────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/plan")
def plan(request: TripRequest):
    """Run the full crew synchronously and return the complete trip plan."""
    tracer = get_tracer()
    trip = request.model_dump()

    with tracer.start_as_current_span("plan_trip") as span:
        span.set_attribute("origin", trip["origin"])
        span.set_attribute("budget_level", trip["budget_level"])
        start = time.time()
        try:
            result = plan_trip(trip)
            trip_requests_total.labels(status="success").inc()
            trip_duration_seconds.observe(time.time() - start)
            return JSONResponse(content=result)
        except Exception as e:
            trip_requests_total.labels(status="error").inc()
            span.record_exception(e)
            raise HTTPException(status_code=500, detail=str(e))


@app.post("/plan/stream")
async def plan_stream(request: TripRequest):
    """
    Stream agent progress as Server-Sent Events.
    Each event has: { "agent": str, "status": str, "output": str }
    """
    trip = request.model_dump()

    async def event_generator() -> AsyncGenerator[dict, None]:
        agents_order = [
            ("destination_researcher", "Researching destinations..."),
            ("flight_scout", "Scouting flights..."),
            ("hotel_curator", "Curating hotels..."),
            ("itinerary_planner", "Building itinerary..."),
            ("budget_analyst", "Analyzing budget..."),
        ]

        # Run crew in a thread to avoid blocking the event loop
        loop = asyncio.get_event_loop()
        result_holder: dict = {}

        async def run_crew():
            result_holder["data"] = await loop.run_in_executor(None, plan_trip, trip)

        crew_task = asyncio.create_task(run_crew())

        # Stream progress events while crew runs
        for agent_name, status_msg in agents_order:
            yield {"event": "progress", "data": f'{{"agent": "{agent_name}", "status": "{status_msg}"}}'}
            # Wait proportionally — real progress would hook into CrewAI callbacks
            await asyncio.sleep(1)

        await crew_task

        result = result_holder.get("data", {})
        for key, value in result.items():
            if key != "summary":
                safe_value = value.replace('"', '\\"').replace("\n", "\\n")
                yield {"event": "result", "data": f'{{"section": "{key}", "content": "{safe_value}"}}'}

        yield {"event": "done", "data": '{"status": "complete"}'}

    return EventSourceResponse(event_generator())


if __name__ == "__main__":
    import uvicorn
    import os
    uvicorn.run("app:app", host="0.0.0.0", port=int(os.getenv("PORT", 8000)), reload=True)
