"""
Custom tools for the travel planning crew.
Uses SerperDevTool when SERPER_API_KEY is set, otherwise falls back to mock data.
"""
import os
import json
from crewai.tools import tool

_USE_SERPER = bool(os.getenv("SERPER_API_KEY"))

if _USE_SERPER:
    from crewai_tools import SerperDevTool
    web_search_tool = SerperDevTool()
else:
    @tool("web_search")
    def web_search_tool(query: str) -> str:
        """Search the web for travel information."""
        return f"[Mock] Search results for: {query}\n- Top result: Example travel info for '{query}'"


@tool("destination_info")
def destination_info_tool(destination: str) -> str:
    """Get key facts about a travel destination: climate, visa, currency, safety."""
    data = {
        "paris": {"climate": "Temperate", "visa": "Schengen", "currency": "EUR", "safety": "High"},
        "tokyo": {"climate": "Humid subtropical", "visa": "Visa-free (90 days)", "currency": "JPY", "safety": "Very High"},
        "bali": {"climate": "Tropical", "visa": "Visa on arrival", "currency": "IDR", "safety": "Medium"},
        "new york": {"climate": "Humid continental", "visa": "ESTA/Visa", "currency": "USD", "safety": "Medium"},
        "dubai": {"climate": "Desert", "visa": "Visa on arrival", "currency": "AED", "safety": "High"},
    }
    key = destination.lower()
    info = data.get(key, {"climate": "Varies", "visa": "Check embassy", "currency": "Local", "safety": "Check advisories"})
    return json.dumps({"destination": destination, **info})


@tool("flight_search")
def flight_search_tool(origin: str, destination: str, date: str) -> str:
    """Search for available flights between two cities on a given date."""
    return json.dumps({
        "origin": origin,
        "destination": destination,
        "date": date,
        "options": [
            {"airline": "SkyWings", "departure": "08:00", "arrival": "14:30", "price_usd": 420, "stops": 0},
            {"airline": "GlobalAir", "departure": "11:15", "arrival": "19:45", "price_usd": 310, "stops": 1},
            {"airline": "BudgetFly", "departure": "23:00", "arrival": "09:00+1", "price_usd": 195, "stops": 1},
        ]
    })


@tool("hotel_search")
def hotel_search_tool(destination: str, checkin: str, checkout: str, budget_per_night_usd: int) -> str:
    """Search for hotels at a destination within a nightly budget."""
    return json.dumps({
        "destination": destination,
        "checkin": checkin,
        "checkout": checkout,
        "results": [
            {"name": "Grand Plaza Hotel", "stars": 5, "price_per_night": budget_per_night_usd * 1.2, "amenities": ["pool", "spa", "gym"]},
            {"name": "City Center Inn", "stars": 3, "price_per_night": budget_per_night_usd * 0.7, "amenities": ["wifi", "breakfast"]},
            {"name": "Boutique Stay", "stars": 4, "price_per_night": budget_per_night_usd * 0.95, "amenities": ["wifi", "rooftop bar"]},
        ]
    })


@tool("currency_converter")
def currency_converter_tool(amount: float, from_currency: str, to_currency: str) -> str:
    """Convert an amount between currencies using approximate rates."""
    rates_to_usd = {"USD": 1.0, "EUR": 1.08, "JPY": 0.0067, "GBP": 1.27, "AED": 0.27, "IDR": 0.000063}
    from_rate = rates_to_usd.get(from_currency.upper(), 1.0)
    to_rate = rates_to_usd.get(to_currency.upper(), 1.0)
    converted = amount * from_rate / to_rate
    return f"{amount} {from_currency} ≈ {converted:.2f} {to_currency}"


@tool("weather_forecast")
def weather_forecast_tool(destination: str, month: str) -> str:
    """Get typical weather conditions for a destination in a given month."""
    return json.dumps({
        "destination": destination,
        "month": month,
        "avg_temp_c": 22,
        "avg_temp_f": 72,
        "conditions": "Partly cloudy with occasional showers",
        "recommendation": "Pack light layers and a compact umbrella"
    })
