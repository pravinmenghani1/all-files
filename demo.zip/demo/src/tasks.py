"""
Tasks for each travel agent. Each task has a clear description, expected output,
and is assigned to the appropriate agent.
"""
from crewai import Task
from crewai import Agent


def research_destinations_task(agent: Agent, trip_request: dict) -> Task:
    return Task(
        description=(
            f"Research travel destinations for the following request:\n"
            f"- Origin: {trip_request['origin']}\n"
            f"- Interests: {trip_request['interests']}\n"
            f"- Travel dates: {trip_request['travel_dates']}\n"
            f"- Budget level: {trip_request['budget_level']}\n\n"
            "Recommend 2-3 destinations with: why it matches, best time to visit, "
            "visa requirements, local currency, and safety rating."
        ),
        expected_output=(
            "A structured report with 2-3 destination recommendations, each including: "
            "destination name, match score (1-10), key highlights, visa info, currency, "
            "weather during travel dates, and safety rating."
        ),
        agent=agent,
    )


def find_flights_task(agent: Agent, trip_request: dict, destination_report: Task) -> Task:
    return Task(
        description=(
            f"Find the best flight options from {trip_request['origin']} to the top "
            f"destination recommended in the research report.\n"
            f"Travel dates: {trip_request['travel_dates']}\n"
            f"Budget level: {trip_request['budget_level']}\n\n"
            "Compare at least 3 flight options and recommend the best value choice."
        ),
        expected_output=(
            "A flight comparison table with: airline, departure/arrival times, duration, "
            "stops, price in USD, and a final recommendation with justification."
        ),
        agent=agent,
        context=[destination_report],
    )


def find_hotels_task(agent: Agent, trip_request: dict, destination_report: Task) -> Task:
    return Task(
        description=(
            f"Find the best hotel options at the recommended destination.\n"
            f"Check-in/out: {trip_request['travel_dates']}\n"
            f"Budget level: {trip_request['budget_level']}\n"
            f"Travelers: {trip_request.get('travelers', 2)}\n\n"
            "Compare 3 accommodation options across different price tiers."
        ),
        expected_output=(
            "A hotel comparison with: name, star rating, price per night, key amenities, "
            "location pros/cons, and a top pick recommendation."
        ),
        agent=agent,
        context=[destination_report],
    )


def create_itinerary_task(
    agent: Agent, trip_request: dict,
    destination_report: Task, flights_task: Task, hotels_task: Task
) -> Task:
    return Task(
        description=(
            f"Create a detailed day-by-day itinerary for the trip.\n"
            f"Interests: {trip_request['interests']}\n"
            f"Travel dates: {trip_request['travel_dates']}\n"
            f"Travelers: {trip_request.get('travelers', 2)}\n\n"
            "Use the destination research, flight, and hotel information to build a "
            "realistic schedule. Include morning/afternoon/evening activities, "
            "local dining recommendations, and travel tips."
        ),
        expected_output=(
            "A complete day-by-day itinerary with: date, morning/afternoon/evening activities, "
            "recommended restaurants, estimated time at each location, and practical tips."
        ),
        agent=agent,
        context=[destination_report, flights_task, hotels_task],
    )


def analyze_budget_task(
    agent: Agent, trip_request: dict,
    flights_task: Task, hotels_task: Task, itinerary_task: Task
) -> Task:
    return Task(
        description=(
            f"Analyze the total trip cost and provide budget optimization tips.\n"
            f"Budget level: {trip_request['budget_level']}\n"
            f"Travelers: {trip_request.get('travelers', 2)}\n\n"
            "Aggregate costs from flights, hotels, and estimated daily expenses. "
            "Provide a breakdown and 3-5 actionable money-saving tips."
        ),
        expected_output=(
            "A budget summary with: itemized cost breakdown (flights, hotels, food, activities, misc), "
            "total per person and total for group, comparison to budget level, "
            "and 3-5 specific money-saving recommendations."
        ),
        agent=agent,
        context=[flights_task, hotels_task, itinerary_task],
    )
