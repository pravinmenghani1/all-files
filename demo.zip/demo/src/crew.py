"""
Assembles the travel planning crew and provides a clean kickoff interface.
"""
from crewai import Crew, Process
from src.agents import (
    destination_researcher, flight_scout,
    hotel_curator, itinerary_planner, budget_analyst,
)
from src.tasks import (
    research_destinations_task, find_flights_task, find_hotels_task,
    create_itinerary_task, analyze_budget_task,
)

# Default trip request used when running this file directly
DEFAULT_TRIP = {
    "origin": "New York",
    "interests": "culture, food, history, photography",
    "travel_dates": "2025-03-10 to 2025-03-17",
    "budget_level": "mid-range",
    "travelers": 2,
}


def build_crew(trip_request: dict) -> Crew:
    """Build and return a configured travel planning crew."""
    # Instantiate agents
    researcher = destination_researcher()
    scout = flight_scout()
    curator = hotel_curator()
    planner = itinerary_planner()
    analyst = budget_analyst()

    # Build tasks with dependencies
    t_research = research_destinations_task(researcher, trip_request)
    t_flights = find_flights_task(scout, trip_request, t_research)
    t_hotels = find_hotels_task(curator, trip_request, t_research)
    t_itinerary = create_itinerary_task(planner, trip_request, t_research, t_flights, t_hotels)
    t_budget = analyze_budget_task(analyst, trip_request, t_flights, t_hotels, t_itinerary)

    return Crew(
        agents=[researcher, scout, curator, planner, analyst],
        tasks=[t_research, t_flights, t_hotels, t_itinerary, t_budget],
        process=Process.sequential,
        verbose=True,
    )


def plan_trip(trip_request: dict) -> dict:
    """
    Run the full travel planning crew and return structured results.

    Returns:
        {
            "destination_research": str,
            "flights": str,
            "hotels": str,
            "itinerary": str,
            "budget": str,
        }
    """
    crew = build_crew(trip_request)
    result = crew.kickoff()

    # CrewAI returns a CrewOutput; extract per-task outputs
    tasks_output = result.tasks_output
    return {
        "destination_research": tasks_output[0].raw if len(tasks_output) > 0 else "",
        "flights": tasks_output[1].raw if len(tasks_output) > 1 else "",
        "hotels": tasks_output[2].raw if len(tasks_output) > 2 else "",
        "itinerary": tasks_output[3].raw if len(tasks_output) > 3 else "",
        "budget": tasks_output[4].raw if len(tasks_output) > 4 else "",
        "summary": result.raw,
    }


if __name__ == "__main__":
    import json
    from dotenv import load_dotenv
    load_dotenv()

    print("\n🌍 Travel Planning Crew — Starting...\n")
    results = plan_trip(DEFAULT_TRIP)
    print("\n" + "=" * 60)
    print("✅ TRIP PLAN COMPLETE")
    print("=" * 60)
    for section, content in results.items():
        if section != "summary":
            print(f"\n📌 {section.upper().replace('_', ' ')}")
            print("-" * 40)
            print(content)
