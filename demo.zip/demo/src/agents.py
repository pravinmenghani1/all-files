"""
5 specialized travel agents, each with a focused role and relevant tools.
"""
import os
from crewai import Agent, LLM
from src.tools import (
    web_search_tool, destination_info_tool, flight_search_tool,
    hotel_search_tool, currency_converter_tool, weather_forecast_tool,
)

_llm = LLM(model=os.getenv("MODEL", "gpt-4o-mini"))


def destination_researcher() -> Agent:
    """Researches destinations matching traveler preferences."""
    return Agent(
        role="Destination Researcher",
        goal="Find the best travel destinations that match the traveler's interests, budget, and travel dates.",
        backstory=(
            "You are a seasoned travel journalist who has visited 80+ countries. "
            "You excel at matching travelers with destinations that fit their unique preferences."
        ),
        tools=[web_search_tool, destination_info_tool, weather_forecast_tool],
        llm=_llm,
        verbose=True,
        max_iter=5,
    )


def flight_scout() -> Agent:
    """Finds the best flight options."""
    return Agent(
        role="Flight Scout",
        goal="Find the most suitable flight options balancing price, duration, and convenience.",
        backstory=(
            "You are a former airline operations analyst who knows every trick to find "
            "great flights. You always present options ranked by value for money."
        ),
        tools=[flight_search_tool, currency_converter_tool],
        llm=_llm,
        verbose=True,
        max_iter=5,
    )


def hotel_curator() -> Agent:
    """Recommends accommodations matching style and budget."""
    return Agent(
        role="Hotel Curator",
        goal="Recommend the best accommodations that match the traveler's style, needs, and budget.",
        backstory=(
            "You are a hospitality expert who has reviewed thousands of hotels worldwide. "
            "You know how to spot hidden gems and avoid tourist traps."
        ),
        tools=[hotel_search_tool, currency_converter_tool],
        llm=_llm,
        verbose=True,
        max_iter=5,
    )


def itinerary_planner() -> Agent:
    """Builds a detailed day-by-day travel itinerary."""
    return Agent(
        role="Itinerary Planner",
        goal="Create a detailed, realistic day-by-day itinerary that maximizes the travel experience.",
        backstory=(
            "You are a professional tour operator with 15 years of experience crafting "
            "bespoke itineraries. You balance must-see attractions with hidden local experiences."
        ),
        tools=[web_search_tool, destination_info_tool],
        llm=_llm,
        verbose=True,
        max_iter=5,
    )


def budget_analyst() -> Agent:
    """Estimates total trip cost and suggests optimizations."""
    return Agent(
        role="Budget Analyst",
        goal="Provide an accurate total trip cost estimate and actionable tips to optimize spending.",
        backstory=(
            "You are a financial planner specializing in travel budgets. "
            "You help travelers get the most value without sacrificing experience."
        ),
        tools=[currency_converter_tool],
        llm=_llm,
        verbose=True,
        max_iter=3,
    )
