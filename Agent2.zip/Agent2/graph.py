from typing import TypedDict, Literal, Annotated
from langgraph.graph import StateGraph, END
import operator

# ── State ──────────────────────────────────────────────────────────────────────

class AppState(TypedDict, total=False):
    applicant: str
    documents: list[str]
    missing: list[str]
    attempts: int
    decision: str
    notification: str

REQUIRED_DOCS = {"id_proof", "income_statement", "application_form"}

# ── Nodes ──────────────────────────────────────────────────────────────────────

def submit(state: AppState) -> AppState:
    attempts = state.get("attempts", 0)
    docs = state.get("documents", [])
    if attempts > 0 and state.get("missing"):
        docs = list(REQUIRED_DOCS)
        print(f"\n📋 [Submit]  {state.get('applicant','Applicant')} (retry #{attempts}) — uploaded missing docs")
    else:
        print(f"\n📋 [Submit]  Applicant: {state.get('applicant','Applicant')}")
    print(f"             Documents: {docs}")
    return {**state, "documents": docs, "missing": [], "attempts": attempts + 1}


def verify(state: AppState) -> AppState:
    submitted = set(state.get("documents", []))
    missing = list(REQUIRED_DOCS - submitted)
    print(f"\n🔍 [Verify]  Missing: {missing if missing else 'None — all docs present'}")
    return {**state, "missing": missing}


def approve_reject(state: AppState) -> AppState:
    if not state.get("missing"):
        print(f"\n✅ [Approve/Reject]  Decision: APPROVED")
        return {**state, "decision": "approved"}
    print(f"\n❌ [Approve/Reject]  Decision: REJECTED (missing: {state['missing']})")
    return {**state, "decision": "rejected"}


def notify(state: AppState) -> AppState:
    name = state.get("applicant", "Applicant")
    if state.get("decision") == "approved":
        msg = f"🎉 Congratulations {name}! Your application is APPROVED."
    else:
        msg = f"⚠️  {name}, your application was REJECTED. Please resubmit with: {state.get('missing', [])}"
    print(f"\n📣 [Notify]  {msg}")
    return {**state, "notification": msg}

# ── Routing ────────────────────────────────────────────────────────────────────

def route_after_verify(state: AppState) -> Literal["approve_reject", "submit"]:
    if state.get("missing") and state.get("attempts", 0) < 3:
        print(f"\n🔁 [Router]  Loop-back triggered (attempt {state['attempts']}/3)")
        return "submit"
    return "approve_reject"

# ── Graph ──────────────────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    g = StateGraph(AppState)
    g.add_node("submit", submit)
    g.add_node("verify", verify)
    g.add_node("approve_reject", approve_reject)
    g.add_node("notify", notify)
    g.set_entry_point("submit")
    g.add_edge("submit", "verify")
    g.add_conditional_edges("verify", route_after_verify)
    g.add_edge("approve_reject", "notify")
    g.add_edge("notify", END)
    return g.compile()

graph = build_graph()
