from dotenv import load_dotenv
from graph import graph

load_dotenv()


def run(label: str, applicant: str, documents: list[str]):
    print(f"\n{'='*55}")
    print(f"🚀 Scenario: {label}")
    print(f"{'='*55}")
    result = graph.invoke({
        "applicant": applicant,
        "documents": documents,
        "missing": [],
        "attempts": 0,
        "decision": "",
        "notification": "",
    })
    print(f"\n📊 Final State → decision={result['decision']}, attempts={result['attempts']}")


if __name__ == "__main__":
    # Scenario 1: all docs present → straight approval
    run(
        label="Clean Pass",
        applicant="Alice",
        documents=["id_proof", "income_statement", "application_form"],
    )

    # Scenario 2: missing doc → loop-back → auto-fix → approval
    run(
        label="Missing Document (loop-back)",
        applicant="Bob",
        documents=["id_proof"],          # missing income_statement + application_form
    )
