import os
import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8000/chat")

st.title("AI Agent Chat")

if "messages" not in st.session_state:
    st.session_state.messages = []

for role, content in st.session_state.messages:
    with st.chat_message(role):
        st.write(content)

if prompt := st.chat_input("Ask anything..."):
    st.session_state.messages.append(("user", prompt))
    with st.chat_message("user"):
        st.write(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            resp = requests.post(API_URL, json={"message": prompt}, timeout=120)
            answer = resp.json()["response"]
            st.write(answer)

    st.session_state.messages.append(("assistant", answer))
