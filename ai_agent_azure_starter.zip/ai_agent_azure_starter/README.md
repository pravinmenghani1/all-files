# AI Agent Azure Starter

Production-ready starter project using:
- FastAPI backend
- OpenAI API
- Streamlit chat UI
- Docker
- Azure Container Apps
- GitHub Actions

## Quick Start

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r app/requirements.txt

cp .env.example .env
# Add your OPENAI_API_KEY

uvicorn app.main:app --reload
```

In another terminal:

```bash
streamlit run ui/streamlit_app.py
```

## Docker

```bash
docker build -t ai-agent .
docker run -p 8000:8000 --env-file .env ai-agent
```

## Deploy to Azure

```bash
chmod +x scripts/deploy.sh
export OPENAI_API_KEY=your_key
./scripts/deploy.sh
```
