#!/bin/bash
set -e

RG=rg-ai-agent
LOCATION=centralindia
ENV=ai-agent-env
APP=ai-agent-app

az group create --name $RG --location $LOCATION
az containerapp env create --name $ENV --resource-group $RG --location $LOCATION

az containerapp up \
  --name $APP \
  --resource-group $RG \
  --environment $ENV \
  --source . \
  --target-port 8000 \
  --ingress external \
  --env-vars OPENAI_API_KEY=$OPENAI_API_KEY OPENAI_MODEL=gpt-5-mini
