from fastapi import FastAPI
from pydantic import BaseModel
from app.agent import ask_agent

app = FastAPI(title="AI Agent API")

class ChatRequest(BaseModel):
    message: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat")
def chat(req: ChatRequest):
    return {"response": ask_agent(req.message)}
