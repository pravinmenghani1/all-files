from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)


def researcher(task: str) -> str:
    """Finds raw information on the given task."""
    print("\n🔍 [Researcher] Working...")
    messages = [
        SystemMessage(content=(
            "You are a research agent. Search your knowledge for the latest AI news. "
            "Return a bullet list of the top 3 AI news stories from today (May 2, 2026) "
            "with a headline and 2-sentence description each."
        )),
        HumanMessage(content=task),
    ]
    response = llm.invoke(messages)
    print(f"   ✅ Done — {response.usage_metadata['total_tokens']} tokens used")
    return response.content


def analyst(research: str) -> str:
    """Analyses and extracts key insights from raw research."""
    print("\n📊 [Analyst] Working...")
    messages = [
        SystemMessage(content=(
            "You are an analyst agent. Given raw research notes, extract the 3 most "
            "important insights and explain why each story matters to the AI industry."
        )),
        HumanMessage(content=research),
    ]
    response = llm.invoke(messages)
    print(f"   ✅ Done — {response.usage_metadata['total_tokens']} tokens used")
    return response.content


def writer(analysis: str) -> str:
    """Writes a polished summary from the analyst's insights."""
    print("\n✍️  [Writer] Working...")
    messages = [
        SystemMessage(content=(
            "You are a writer agent. Turn the analyst's insights into a crisp, "
            "engaging 3-paragraph newsletter-style summary. Use plain language."
        )),
        HumanMessage(content=analysis),
    ]
    response = llm.invoke(messages)
    print(f"   ✅ Done — {response.usage_metadata['total_tokens']} tokens used")
    return response.content
