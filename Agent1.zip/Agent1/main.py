import os
import time
import json
from datetime import datetime, timezone
from dotenv import load_dotenv
from agents import researcher, analyst, writer

load_dotenv()

TASK = "Summarize today's top 3 AI news stories (May 2, 2026)"
TRACE_FILE = "trace.json"


def ts():
    return datetime.now(timezone.utc).isoformat()


def run_pipeline(task: str) -> str:
    trace = {"pipeline": "multi-agent-pipeline", "task": task, "steps": []}
    wall_start = time.time()

    print(f"\n🚀 Pipeline started\n   Task: {task}")
    print("=" * 55)

    # --- Researcher ---
    t0 = time.time()
    research = researcher(task)
    trace["steps"].append({"agent": "Researcher", "latency_s": round(time.time() - t0, 2),
                           "output_chars": len(research)})
    print("   📤 Handoff: Researcher → Analyst")

    # --- Analyst ---
    t0 = time.time()
    analysis = analyst(research)
    trace["steps"].append({"agent": "Analyst", "latency_s": round(time.time() - t0, 2),
                           "output_chars": len(analysis)})
    print("   📤 Handoff: Analyst → Writer")

    # --- Writer ---
    t0 = time.time()
    final = writer(analysis)
    trace["steps"].append({"agent": "Writer", "latency_s": round(time.time() - t0, 2),
                           "output_chars": len(final)})

    elapsed = round(time.time() - wall_start, 2)
    trace["total_latency_s"] = elapsed
    trace["timestamp"] = ts()

    with open(TRACE_FILE, "w") as f:
        json.dump(trace, f, indent=2)

    print("\n" + "=" * 55)
    print(f"⏱️  Total latency: {elapsed}s")
    print(f"📁 Trace saved → {TRACE_FILE}")
    print("\n📰 FINAL OUTPUT:\n")
    print(final)

    # LangSmith (optional — only if key works)
    ls_key = os.getenv("LANGCHAIN_API_KEY", "")
    if ls_key and os.getenv("LANGCHAIN_TRACING_V2") == "true":
        print("\n✅ LangSmith trace → https://smith.langchain.com")

    return final


if __name__ == "__main__":
    run_pipeline(TASK)
