# 🛡️ AI Content Moderation & Publishing System
# Copy each section to separate Colab cells

# ============================================================================
# CELL 1: Install Dependencies
# What this does: Installs required packages
# ============================================================================
# !pip install -q langgraph langchain-openai networkx matplotlib

# ============================================================================
# CELL 2: Imports
# What this does: Imports all required libraries
# ============================================================================
from typing import Annotated
from typing_extensions import TypedDict
from operator import add
from langgraph.graph import StateGraph, START, END
import datetime, os
from langchain_openai import ChatOpenAI
from google.colab import userdata

# ============================================================================
# CELL 3: Initialize GPT-4o
# What this does: Sets up the AI model (add API key to Colab Secrets)
# ============================================================================
os.environ["OPENAI_API_KEY"] = userdata.get('OPENAI_API_KEY')
llm = ChatOpenAI(model="gpt-4o", temperature=0.3)
print("✓ GPT-4o initialized")

# ============================================================================
# CELL 4: Define State
# What this does: Defines data structure that flows through workflow
# Annotated[list, add] allows parallel agents to update moderation_log
# ============================================================================
class ContentState(TypedDict):
    content_id: str; author: str; content_text: str; content_type: str
    toxicity_score: float; spam_score: float; copyright_score: float
    toxicity_details: str; spam_details: str; copyright_details: str
    risk_level: str; risk_reasoning: str
    seo_tags: str; formatted_content: str
    publish_status: str; publish_time: str; rejection_reason: str
    moderation_log: Annotated[list, add]  # Parallel-safe
    status: str

# ============================================================================
# CELL 5: Intake Agent (Sequential)
# What this does: First agent - receives and logs content submission
# ============================================================================
def intake_agent(state: ContentState) -> dict:
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return {
        'status': 'received',
        'moderation_log': [f'[{ts}] Content {state["content_id"]} received from {state["author"]}']
    }
print("✓ Intake agent defined")

# ============================================================================
# CELL 6: Parallel Moderation Agents
# What this does: 3 agents run SIMULTANEOUSLY checking different safety aspects
# Each scores content 0-10 using GPT-4o
# ============================================================================
def toxicity_agent(state: ContentState) -> dict:
    """Checks for hate speech, harassment, threats"""
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    prompt = f'Analyze toxicity (hate/harassment). Content: {state["content_text"]}. Respond: Score: [0-10] Details: [explanation]'
    resp = llm.invoke(prompt).content
    score = 0.0; details = ''
    for line in resp.split('\n'):
        if 'Score:' in line:
            try: score = float(line.split(':')[1].strip().split()[0])
            except: score = 0.0
        elif 'Details:' in line: details = line.split(':', 1)[1].strip()
    return {'toxicity_score': score, 'toxicity_details': details, 'moderation_log': [f'[{ts}] Toxicity: {score}/10']}

def spam_agent(state: ContentState) -> dict:
    """Checks for spam, promotional content"""
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    prompt = f'Analyze spam (promotional/repetitive). Content: {state["content_text"]}. Respond: Score: [0-10] Details: [explanation]'
    resp = llm.invoke(prompt).content
    score = 0.0; details = ''
    for line in resp.split('\n'):
        if 'Score:' in line:
            try: score = float(line.split(':')[1].strip().split()[0])
            except: score = 0.0
        elif 'Details:' in line: details = line.split(':', 1)[1].strip()
    return {'spam_score': score, 'spam_details': details, 'moderation_log': [f'[{ts}] Spam: {score}/10']}

def copyright_agent(state: ContentState) -> dict:
    """Checks for plagiarism, copyright violations"""
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    prompt = f'Analyze copyright (plagiarism). Content: {state["content_text"]}. Respond: Score: [0-10] Details: [explanation]'
    resp = llm.invoke(prompt).content
    score = 0.0; details = ''
    for line in resp.split('\n'):
        if 'Score:' in line:
            try: score = float(line.split(':')[1].strip().split()[0])
            except: score = 0.0
        elif 'Details:' in line: details = line.split(':', 1)[1].strip()
    return {'copyright_score': score, 'copyright_details': details, 'moderation_log': [f'[{ts}] Copyright: {score}/10']}

print("✓ 3 parallel moderation agents defined")

# ============================================================================
# CELL 7: Risk Assessment Agent (Sequential)
# What this does: Runs AFTER parallel agents, combines scores to decide risk level
# Logic: ≥8=reject, 5-7=review, <5=safe
# ============================================================================
def risk_assessment_agent(state: ContentState) -> dict:
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    max_score = max(state['toxicity_score'], state['spam_score'], state['copyright_score'])
    if max_score >= 8: risk, reason = 'reject', f'High risk ({max_score}/10)'
    elif max_score >= 5: risk, reason = 'review', f'Medium risk ({max_score}/10)'
    else: risk, reason = 'safe', f'Low risk ({max_score}/10)'
    return {'risk_level': risk, 'risk_reasoning': reason, 'status': 'assessed', 'moderation_log': [f'[{ts}] Risk: {risk.upper()}']}
print("✓ Risk assessment agent defined")

# ============================================================================
# CELL 8: Routing Function (Conditional)
# What this does: AI-driven decision - routes to different paths based on risk
# safe→enhancement, review→human, reject→rejection
# ============================================================================
def route_content(state: ContentState) -> str:
    return {'safe': 'enhancement_agent', 'review': 'human_review_agent', 'reject': 'rejection_agent'}[state['risk_level']]
print("✓ Routing function defined")

# ============================================================================
# CELL 9: Enhancement Agent (Safe Path Only)
# What this does: Improves approved content with SEO and formatting using GPT-4o
# ============================================================================
def enhancement_agent(state: ContentState) -> dict:
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    seo = llm.invoke(f'Generate 5 SEO tags for: {state["content_text"][:200]}').content
    formatted = llm.invoke(f'Improve formatting: {state["content_text"]}').content
    return {'seo_tags': seo, 'formatted_content': formatted, 'status': 'enhanced', 'moderation_log': [f'[{ts}] Enhanced']}
print("✓ Enhancement agent defined")

# ============================================================================
# CELL 10: Human Review Agent (Review Path)
# What this does: Flags medium-risk content for human moderators
# ============================================================================
def human_review_agent(state: ContentState) -> dict:
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    notes = f'REVIEW NEEDED: Toxicity {state["toxicity_score"]}, Spam {state["spam_score"]}, Copyright {state["copyright_score"]}'
    return {'publish_status': 'pending_review', 'formatted_content': notes, 'status': 'awaiting_human', 'moderation_log': [f'[{ts}] Flagged']}
print("✓ Human review agent defined")

# ============================================================================
# CELL 11: Rejection Agent (Reject Path)
# What this does: Blocks high-risk content, generates rejection message
# ============================================================================
def rejection_agent(state: ContentState) -> dict:
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    msg = llm.invoke(f'Create professional rejection for content with Toxicity {state["toxicity_score"]}, Spam {state["spam_score"]}').content
    return {'publish_status': 'rejected', 'rejection_reason': msg, 'status': 'rejected', 'moderation_log': [f'[{ts}] Rejected']}
print("✓ Rejection agent defined")

# ============================================================================
# CELL 12: Publishing Agent (Final Step)
# What this does: Publishes approved content, records timestamp
# ============================================================================
def publishing_agent(state: ContentState) -> dict:
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return {'publish_status': 'published', 'publish_time': ts, 'status': 'live', 'moderation_log': [f'[{ts}] Published']}
print("✓ Publishing agent defined")

# ============================================================================
# CELL 13: Build Complete Workflow
# What this does: Orchestrates all agents - Sequential→Parallel→Conditional→Sequential
# ============================================================================
workflow = StateGraph(ContentState)

# Add all agents
workflow.add_node('intake', intake_agent)
workflow.add_node('toxicity', toxicity_agent)
workflow.add_node('spam', spam_agent)
workflow.add_node('copyright', copyright_agent)
workflow.add_node('risk_assessment', risk_assessment_agent)
workflow.add_node('enhancement_agent', enhancement_agent)
workflow.add_node('human_review_agent', human_review_agent)
workflow.add_node('rejection_agent', rejection_agent)
workflow.add_node('publishing', publishing_agent)

# Sequential start
workflow.set_entry_point('intake')

# Parallel moderation (3 agents run simultaneously)
workflow.add_edge('intake', 'toxicity')
workflow.add_edge('intake', 'spam')
workflow.add_edge('intake', 'copyright')

# Converge to risk assessment
workflow.add_edge('toxicity', 'risk_assessment')
workflow.add_edge('spam', 'risk_assessment')
workflow.add_edge('copyright', 'risk_assessment')

# Conditional routing
workflow.add_conditional_edges('risk_assessment', route_content, {
    'enhancement_agent': 'enhancement_agent',
    'human_review_agent': 'human_review_agent',
    'rejection_agent': 'rejection_agent'
})

# Final steps
workflow.add_edge('enhancement_agent', 'publishing')
workflow.add_edge('publishing', END)
workflow.add_edge('human_review_agent', END)
workflow.add_edge('rejection_agent', END)

moderation_system = workflow.compile()
print("✓ Workflow compiled successfully")

# ============================================================================
# CELL 14: Test Case 1 - Safe Content
# What this does: Tests happy path - clean content gets enhanced and published
# ============================================================================
content1 = {
    'content_id': 'POST-001', 'author': 'Alice',
    'content_text': 'Just finished reading an amazing book about AI and machine learning. Highly recommend it!',
    'content_type': 'post', 'toxicity_score': 0.0, 'spam_score': 0.0, 'copyright_score': 0.0,
    'toxicity_details': '', 'spam_details': '', 'copyright_details': '',
    'risk_level': '', 'risk_reasoning': '', 'seo_tags': '', 'formatted_content': '',
    'publish_status': '', 'publish_time': '', 'rejection_reason': '',
    'moderation_log': [], 'status': 'new'
}
print("🧪 Testing safe content...")
result1 = moderation_system.invoke(content1)
print("✓ Complete")

# ============================================================================
# CELL 15: Display Safe Content Results
# ============================================================================
print('='*80)
print('📋 MODERATION SCORES')
print('='*80)
print(f'Toxicity: {result1["toxicity_score"]}/10')
print(f'Spam: {result1["spam_score"]}/10')
print(f'Copyright: {result1["copyright_score"]}/10')
print(f'Risk Level: {result1["risk_level"].upper()}')
print(f'Status: {result1["status"].upper()}\n')

print('='*80)
print('✨ ENHANCED CONTENT')
print('='*80)
print(f'SEO Tags: {result1["seo_tags"]}')
print(f'\nFormatted:\n{result1["formatted_content"][:300]}...\n')

print('='*80)
print('📝 ACTIVITY LOG')
print('='*80)
for log in result1['moderation_log']: print(log)

# ============================================================================
# CELL 16: Test Case 2 - Toxic Content
# What this does: Tests rejection path - toxic content gets blocked
# ============================================================================
content2 = {
    'content_id': 'POST-002', 'author': 'BadActor',
    'content_text': 'I hate everyone in this group. You are all idiots and should be banned!',
    'content_type': 'comment', 'toxicity_score': 0.0, 'spam_score': 0.0, 'copyright_score': 0.0,
    'toxicity_details': '', 'spam_details': '', 'copyright_details': '',
    'risk_level': '', 'risk_reasoning': '', 'seo_tags': '', 'formatted_content': '',
    'publish_status': '', 'publish_time': '', 'rejection_reason': '',
    'moderation_log': [], 'status': 'new'
}
print("🧪 Testing toxic content...")
result2 = moderation_system.invoke(content2)
print("✓ Complete")

# ============================================================================
# CELL 17: Display Toxic Content Results
# ============================================================================
print('='*80)
print('⚠️ MODERATION SCORES')
print('='*80)
print(f'Toxicity: {result2["toxicity_score"]}/10 ⚠️')
print(f'Risk Level: {result2["risk_level"].upper()}')
print(f'Status: {result2["status"].upper()}\n')

print('='*80)
print('❌ REJECTION MESSAGE')
print('='*80)
print(result2['rejection_reason'])

print('\n' + '='*80)
print('📝 ACTIVITY LOG')
print('='*80)
for log in result2['moderation_log']: print(log)
